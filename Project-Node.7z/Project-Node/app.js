//Cria um arquivo

/*

const fs = require('fs') // 'fs' é o nome da ferramenta node.

let message = 'Vinicius'
fs.writeFileSync('notes.txt', message) // Se rodar essa linha de código com o mesmo nome de arquivo e uma mensagem diferente, vai update a msg.
message = message + ' Andrade'
fs.writeFileSync('notes.txt', message)

*/


/*
require('./utils.js') // Chama as linhas de códigos executadas de utils.js

const name = 'Vinicius'

console.log(name)
*/

/*

const soma = require('./utils.js')

resultadoSoma = soma(1, 3)

console.log(resultadoSoma)

*/

// require('validator') // Chamar um modulo do framework

const validator = require('validator') // npm install validator
const fs = require('fs') // Ferramenta nativa node que cria arquivos.
//const chalk = require('chalk') // Coloca cores no terminal, por algum caralho de motivo nesse pc não suporta.

//let message = 'vinicius@ibm.com'

//console.log(chalk.blue(message))

//console.log(validator.isEmail(message))

/*

const command = console.log(process.argv[0]) // Inserir dados pelo console. Ex: node app.js Vinicius

if (command === 'add') {

    console.log('Add Note!')

} else if (command === 'remove') {

    console.log('Removing note!')

}

*/

const yargs = require('yargs')
const { argv } = require('process')

/*

// console.log(process.argv)

yargs.command({ // Se escrever add executa a funcao q esta no handler

    command: 'add',
    describe: 'Add a new note',
    handler: () => {

        console.log('Adding a new note')

    }

})

yargs.command({ // Se escrever add executa a funcao q esta no handler

    command: 'remove',
    describe: 'Removing a note',
    handler: () => {

        console.log('Removing a note')

    }

})

console.log(yargs.argv)

*/

/*

yargs.command({ // Se escrever add executa a funcao q esta no handler

    command: 'add',
    describe: 'Add a note',
    builder: {

        title: {

            describe: 'Note title',
            demandOption: true

        }

    },

    handler: (argv) => {

        console.log('Adding a new note', argv)

    }

})

yargs.command({ // Se escrever add executa a funcao q esta no handler

    command: 'Title',
    describe: 'Title a new note',
    title: {

        describe: 'title',
        demandOption: true

    },
    handler: (argv) => {

        console.log('title: ' + argv.title)

    }

})

console.log(yargs.argv)

*/


