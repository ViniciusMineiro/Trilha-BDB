// "use strict"; --> Fica dentro de uma string para poder rodar em navegadores novos e antigos.

/*

function useStrict() {

    "use strict"; // Ativa o modo estrito em uma funcao.

}

*/

"use strict";

var v1 = 0;

vv1 = 1;

if (v1 > 0) {

    console.log(`v1`);

}
