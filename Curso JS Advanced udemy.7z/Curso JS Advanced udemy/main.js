// "use strict"; --> Fica dentro de uma string para poder rodar em navegadores novos e antigos.

/*

function useStrict() {

    "use strict"; // Ativa o modo estrito em uma funcao.

}

*/

/*

"use strict";

var v1 = 0;

vv1 = 1;

if (v1 > 0) {

    console.log(`v1`);

}

*/

/*

function login(method, ...options) {

    var options = Array.prototype.slice.call(arguments, 1); // arguments.slice(1); // 1,2,3,4 = arguments // .slice(posicao) oculta, na matriz, a posicao escolhida.

    console.log(method);
    console.log(options);

}

login("facebook", 1, 2, 3, 4);

*/

/*

// Forma mais eficiente de manipular parametros e exibilos.
// Funcao de descanso?
// Náo precisa declarar varias variaveis no parametro, parece um vetor.
// ...options é chamado de operador de resto, pois, quando o console exibe o method sozinho faz o ...options entender que deve excluir o method pois ja foi exibido, portanto, quando o console exibe options, so vai aparecer os dados restantes.
function login(method, ...options) { //...options sempre como ultimo parametro

    console.log(method); // options.push(5); // Adiciona um uma opcao de parametro.
    console.log(options);

}

login(`facebook`, 1, 2, 3, 4); // Define a quantidade de parametros aqui. Ou seja, pode definir a quantidade de parametros enquanto ordena que os exiba.

 */



// É uma forma de adicionar e concatenar os valores de dentro de um vetor em outro, se n fizer dessa forma vai ser criado um vetor1 dentro da posicao 4 do vetor2 contendo os valores 4,5,6 dentro. Vetor dentro de vetor.
// var vetor1 = [4, 5, 6];
// var vetor2 = [1, 2, 3, ...vetor1]; // pode adicionar o ...vetor1 em qualquer posicao.

// console.log(vetor2);

/*
var array1 = [1, 2, 3];
let array2 = [...array1]; // Cópia dos dados da array1.

array1[0] = -1; // Se alterar a o dado da array1, n altera na array2, pois os dados foram somente copiados e nao relacionados.

console.log(array1);
console.log(array2);

*/

/*

// Uma forma de utilizar variaveis ao inves de setar diretamente valores nos parametros.
const rede = `twitter`;
let ops = ["key", "callbackurl"];

function login(redesocial, ...options) {

    console.log(redesocial);
    console.log(options);

}

login(rede, ...ops);

*/

/*

// Template String tag:

// A funcao serve para formatar a string.
function h1(strings) {

    return "<h1>" + strings + "</h1>";

}

console.log(h1`vinicius`);

// Site styled components

*/

/*

// What are functions clouseres?

// Preenche valores em um vetor.
var foo = [];

for (var i = 0; i < 10; i++) {

    (function () {

        var y = i;
        foo[i] = function() { return y };

    })();

}

console.log(foo[0]);
console.log(foo[1]);
console.log(foo[5]);

*/

/*

var foo = [];

for (var i = 0; i < 10; i++) {

    (function (y) {

        foo[y] = function () { return y };

    })(i);

}

console.log(foo[0]);
console.log(foo[1]);
console.log(foo[5]);

*/

// console.log(typeof (null));

/*

const obj = { first: `name`, last: `name2`, age: 42 }

const { firstname, lastname } = obj;

console.log(lastname);

*/

/*

function f(x = 0) {

    console.log(x);

}

f({ x: 4 });

*/

/*

function a() {

    console.log(this);

};

console.log(a.name);

*/

/*

var asim = {

    chechThis: function () {

        console.log(this);

    }

}

var func = asim.chechThis; // o this vai se conectar no window, afinal o parametro de func e vazio
func();

*/

/*

var asim = {

    checkThis: function () {

        console.log(this);

        function checkOther() {

            console.log(this);
        }

        checkOther(this);
    }

}

//var func = asim.checkThis; // o this vai se conectar no window, afinal o parametro de func e vazio
//func();

*/

/*

function a() {

    console.log(this);

}

a.call(1); // Para fazer o 1 ser relacionado com o this precisa usar a funcao call.
a(1);

*/

/*

var asim = {

    checkThis: function () {

        function checkOther() {

            console.log(this);

        }

        checkOther.call(this);

    }

}

asim.checkThis();


*/

/*

function a(b, c, d) {

    console.log(this);
    console.log(b);
    console.log(c);
    console.log(d);

}

a.call(1, 2, 3, 4, 5, 6);

*/

/*

function soma() {

    for (var i = 0; i < arguments.length; i++) { //arguments.length serve para coletar os parametros adicionados quando chamou a funcao.

        total += arguments[i]; // somando os parametros

    }

    return total; // retorna o valor resultado

}

var x = soma(1, 2, 3);

console.log(x);

*/

/*

// Usar this em funcao anonima sem parametro
// Metodo bind.

var a = function () {

    console.log(this);

}.bind(100);

a();

*/

/*

var asim = {

    checkThis: function () {

        var checkOther = function () {

            console.log(this);

        }.bind(this);

        checkOther();

    }

}

asim.checkThis();

*/

/*

//Funcoes gordas, fat arrow. () =>
// Sao funcoes que tem outroas funcoes como parametro

seTimeout(() => {

    console.log(`seTimeout is called!`);

}, 1000, 1)

*/

/*

let obj = {

    name: `vinicius`,
    sayLater: (name) => console.log(this.name) // N retorna o nome!

};

obj.sayLater(); 

*/

let obj = {

    name: `assim`,
    sayLater: function () {
        // () => se refere ao de cima, se o function fosse tbm fat o this iria chamar window.
        setTimeout(() => { console.log(`${this.name}`); }, 1000);

    }

};

obj.sayLater();