// "use strict"; --> Fica dentro de uma string para poder rodar em navegadores novos e antigos.

/*

function useStrict() {

    "use strict"; // Ativa o modo estrito em uma funcao.

}

*/

/*

"use strict";

var v1 = 0;

vv1 = 1;

if (v1 > 0) {

    console.log(`v1`);

}

*/

/*

function login(method, ...options) {

    var options = Array.prototype.slice.call(arguments, 1); // arguments.slice(1); // 1,2,3,4 = arguments // .slice(posicao) oculta, na matriz, a posicao escolhida.

    console.log(method);
    console.log(options);

}

login("facebook", 1, 2, 3, 4);

*/

/*

// Forma mais eficiente de manipular parametros e exibilos.
// Funcao de descanso?
// Náo precisa declarar varias variaveis no parametro, parece um vetor.
// ...options é chamado de operador de resto, pois, quando o console exibe o method sozinho faz o ...options entender que deve excluir o method pois ja foi exibido, portanto, quando o console exibe options, so vai aparecer os dados restantes.
function login(method, ...options) { //...options sempre como ultimo parametro

    console.log(method); // options.push(5); // Adiciona um uma opcao de parametro.
    console.log(options);

}

login(`facebook`, 1, 2, 3, 4); // Define a quantidade de parametros aqui. Ou seja, pode definir a quantidade de parametros enquanto ordena que os exiba.

 */



// É uma forma de adicionar e concatenar os valores de dentro de um vetor em outro, se n fizer dessa forma vai ser criado um vetor1 dentro da posicao 4 do vetor2 contendo os valores 4,5,6 dentro. Vetor dentro de vetor.
// var vetor1 = [4, 5, 6];
// var vetor2 = [1, 2, 3, ...vetor1]; // pode adicionar o ...vetor1 em qualquer posicao.

// console.log(vetor2);

/*
var array1 = [1, 2, 3];
let array2 = [...array1]; // Cópia dos dados da array1.

array1[0] = -1; // Se alterar a o dado da array1, n altera na array2, pois os dados foram somente copiados e nao relacionados.

console.log(array1);
console.log(array2);

*/

/*

// Uma forma de utilizar variaveis ao inves de setar diretamente valores nos parametros.
const rede = `twitter`;
let ops = ["key", "callbackurl"];

function login(redesocial, ...options) {

    console.log(redesocial);
    console.log(options);

}

login(rede, ...ops);

*/

/*

// Template String tag:

// A funcao serve para formatar a string.
function h1(strings) {

    return "<h1>" + strings + "</h1>";

}

console.log(h1`vinicius`);

// Site styled components

*/

/*

// What are functions clouseres?

// Preenche valores em um vetor.
var foo = [];

for (var i = 0; i < 10; i++) {

    (function () {

        var y = i;
        foo[i] = function() { return y };

    })();

}

console.log(foo[0]);
console.log(foo[1]);
console.log(foo[5]);

*/

/*

var foo = [];

for (var i = 0; i < 10; i++) {

    (function (y) {

        foo[y] = function () { return y };

    })(i);

}

console.log(foo[0]);
console.log(foo[1]);
console.log(foo[5]);

*/

// console.log(typeof (null));

/*

const obj = { first: `name`, last: `name2`, age: 42 }

const { firstname, lastname } = obj;

console.log(lastname);

*/

/*

function f(x = 0) {

    console.log(x);

}

f({ x: 4 });

*/

/*

function a() {

    console.log(this);

};

console.log(a.name);

*/

/*

var asim = {

    chechThis: function () {

        console.log(this);

    }

}

var func = asim.chechThis; // o this vai se conectar no window, afinal o parametro de func e vazio
func();

*/

/*

var asim = {

    checkThis: function () {

        console.log(this);

        function checkOther() {

            console.log(this);
        }

        checkOther(this);
    }

}

//var func = asim.checkThis; // o this vai se conectar no window, afinal o parametro de func e vazio
//func();

*/

/*

function a() {

    console.log(this);

}

a.call(1); // Para fazer o 1 ser relacionado com o this precisa usar a funcao call.
a(1);

*/

/*

var asim = {

    checkThis: function () {

        function checkOther() {

            console.log(this);

        }

        checkOther.call(this);

    }

}

asim.checkThis();


*/

/*

function a(b, c, d) {

    console.log(this);
    console.log(b);
    console.log(c);
    console.log(d);

}

a.call(1, 2, 3, 4, 5, 6);

*/

/*

function soma() {

    for (var i = 0; i < arguments.length; i++) { //arguments.length serve para coletar os parametros adicionados quando chamou a funcao.

        total += arguments[i]; // somando os parametros

    }

    return total; // retorna o valor resultado

}

var x = soma(1, 2, 3);

console.log(x);

*/

/*

// Usar this em funcao anonima sem parametro
// Metodo bind.

var a = function () {

    console.log(this);

}.bind(100);

a();

*/

/*

var asim = {

    checkThis: function () {

        var checkOther = function () {

            console.log(this);

        }.bind(this);

        checkOther();

    }

}

asim.checkThis();

*/

/*

//Funcoes gordas, fat arrow. () =>
// Sao funcoes que tem outroas funcoes como parametro

seTimeout(() => {

    console.log(`seTimeout is called!`);

}, 1000, 1)

*/

/*

let obj = {

    name: `vinicius`,
    sayLater: (name) => console.log(this.name) // N retorna o nome!

};

obj.sayLater();

*/

/*

let obj = {

    name: `assim`,
    sayLater: function () {
        // () => se refere ao de cima, se o function fosse tbm fat o this iria chamar window.
        setTimeout(() => { console.log(`${this.name}`); }, 1000);

    }

};

obj.sayLater();

*/

/*

var animal = {

    kind: `human`

};

// var asim = {};

// asim.__proto__ = animal; // Prototype é algo que todos os objs tem, portanto, vc pode relacionar ele com outro obj e armazenar os atributos desse outro objeto dentro de proto.

// console.log(asim.kind);

// console.log(animal.isPrototypeOf(asim));

// Uma maneira orientada a obj de criar:

var asim = Object.create(animal, { food: { value: `uva` } }); // Adiciona valores no objeto Asim
console.log(asim.kind); // Mostra que kind: human n se tornou propriedade de asim, somente esta pegando emprestado.

*/

/*

// What does the below code print out?
"use strict";
var a = function sayHello(last_name) {
  console.log("Hello " + this + " " + last_name);
}.bind("Asim");
sayHello();

*/

/*

// Classical oab

"use script";

function Person(first_name, last_name) {

    this.first_name = first_name;
    this.last_name = last_name;
    this.full_name = function () {

        return this.first_name + ` ` + this.last_name;

    }

}

// var dude = new Person("A", "B");
// console.log(dude);

// var dude = {};

// Person.call(dude, "asim", "hussain"); // Primeiro parametro e onde vai armazenar os dados processados pela a funcao.
// console.log(dude);

// Person = construtor
// prototype = metodo do js de acessar, ligar e guardar os dados entre objetos
// full_name_prototype, criou um atributo em person para sua expressao.
Person.prototype.full_name_prototype = function () { // Prototype serve para acessar os valores da funcao construtor, __proto__

    return this.first_name + ` ` + this.last_name;

}

var dude = new Person(`Vinicius`, `Mineiro`);
console.log(dude.full_name());
// console.log(dude.full_name_prototype);

*/


// Maneira de privar a modificacao de variaveis do metodo construtor.

/*

"use strict";

function Person(first_name, last_name) {

    this.first_name = first_name;
    this.last_name = last_name;
    this.full_name = function () { // Manteras funcoes no corpo do construtor simula uma tag private.

        return first_name + ` ` + last_name;

    }

}

var dude = new Person(`Vinicius`, `Andrade`);
console.log(dude.full_name);

*/

/*

"use strict";

function Person(name_first, name_last) {

    this.name_first = name_first;
    this.name_last = name_last;

}

Person.prototype.name_full = function () { // como fazer prof herdar fullname

    return this.name_first + ` ` + this.name_last;

}

function Professional(honorific, name_first, name_last) {

    Person.call(this, name_first, name_last);
    this.honorific = honorific;

}

// Precisa ser antes do protype <=
// JS liga objetos pelo prototype, entao e so fazer uma ligacao entre professional e person.
Professional.prototype = Object.create(Person.prototype);

Professional.prototype.professional_name_full = function () {

    return this.honorific + ` ` + this.name_first + ` ` + this.name_last;

}




var prof = new Professional(`Dev`, `Vinicius`, `Mineiro`);
console.log(prof.professional_name_full);
// console.log(prof.name_full); Erro, pois prof n herdou essa funcao do construtor.
// JS liga objetos pelo prototype, entao e so fazer uma ligacao entre professional e person.

*/

/*

var Person = {

    fullname: function () {

        return this.firstname + ` ` + this.lastname;

    }

}


// Sem o metodo construtor n e definido
var eu = Object.create(Person);
console.log(eu.fullname(`Vinicius`, `Mineiro`));

*/

/*

var Person = {

    init: function (firstname, lastname) {

        this.firstname = this.firstname;
        this.lastname = this.lastname;
        return this;

    },

    fullname: function () {

        return this.firstname + ` ` + this.lastname;

    }

};


// Sem o metodo construtor n e definido
var eu = Object.create(Person);
eu.init("Vinicius", `Mineiro`);
console.log(eu.fullname());

*/

/*

var n1 = `Vinicius1`;
n2 = `Vinicius2`;

var Person = {

    init: function (firstname, lastname) {

        this.firstname = this.firstname;
        this.lastname = this.lastname;
        return this;

    },

    fullname: function () {

        return this.firstname + ` ` + this.lastname;

    }

};


// Sem o metodo construtor n e definido
// Maneira de adicionar dados usando o segundo parametro de Object.create.
var eu = Object.create(Person, { firstname: { value: n1 }, lastname: { value: n2 } });
console.log(eu.fullname());

*/

/*

var Person = {

    fullname: function () {

        return this.firstname + ` ` + this.lastname;

    }

};

function personFactory(firstname, lastname) {

    var person = Object.create(Person);
    //Atribuindo o valor de fisrtname do obj person na variavel person, assim da para resgatar o valor usando a fun
    person.firstname = firstname;
    person.lastname = lastname;
    return person;

}

var eu = personFactory(`Vinicius`, `Mineiro`);
console.log(eu.fullname());

*/

/*

var Person = {

    fullname: function () {

        return this.firstname + ` ` + this.lastname;

    }

};

var Professional = Object.create(Person, {

    init: function (firstname, lastname, honorific) {

        this.firstname = this.firstname;
        this.lastname = this.lastname;
        this.honorific = honorific;
        return this;

    },

    professional_name: {
        value: function () {

            return this.honorific + ` ` + this.firstname + ` ` + this.lastname;

        }

    }

});

function ProfessionalFactory(honorific, firstname, lastname) {

    var human = Object.create(Professional);
    human.honorific = honorific;
    human.firstname = firstname;
    human.lastname = lastname;
    return human;

}

var eu = ProfessionalFactory(`DEV`, `Vinicius`, `Mineiro`);
console.log(eu.professional_name);

*/

//treino

/*

"use strict";

var Funcionario = {

    init: function () {

        this.nome = nome;
        this.sobrenome = sobrenome;
        return this;

    },

    nome: nome,
    sobrenome: sobrenome,

    nomecompleto: function () {

        this.nome + ` ` + this.sobrenome;

    }

}

var nf = Object.create(Funcionario);
nf.init(`Vinicius`, `Mineiro`);
console.log(nf.nomecompleto);

*/

// Treinando.

/*

"use strict";

var funcionario = {

    nomecompleto: function () {

        this.nome + ` ` + this.sobrenome;

    }

};

var profissao = Object.create(funcionario, {

    dados: {

        value: function (nome, sobrenome, salario) {

            this.nome = nome;
            this.sobrenome = sobrenome;
            this.salario = salario;

        }

    },

    nomeesalario: {

        value: function () {

            return `O salário de ` + this.nome + ` ` + this.sobrenome + ` é ` + this.salario + `!`;

        }

    }

});

var pessoa = Object.create(profissao);
pessoa.dados(`Vinicius`, `Mineiro`, 1000);
console.log(pessoa.nomeesalario);

*/

class Person {

    _firstName = "";
    _lastName = "";

    constructor(firstName, lastName) {

        this._firstName = firstName;
        this._lastName = lastName;

    }

    get firstName() { // CHama como person.Firstname, propriedade de Person, nao e uma funcao de fato, ou pelo menos n chama como uma funcao.

        return this._firstName;

    }

    get lastName() { // CHama como person.Firstname, propriedade de Person, nao e uma funcao de fato, ou pelo menos n chama como uma funcao.

        return this._lastName;

    }


    fullname() {

        return `${this.firstName} ${this.lastName}`;

    }

}

let asim = new Person(`asim`, `hussain`);

console.log(asim.fullname());




