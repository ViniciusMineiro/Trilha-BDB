package br.com.aulaapi.entities.peopleatri;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "color")
public class Color {

    @Id
    @Column(name = "color_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonBackReference
    private Integer id;

    @Column(name = "color", nullable = false)
    private String color;

    @JsonManagedReference
    @OneToMany(mappedBy = "color")
    Set<HairColor> hair_color;

//    @ManyToOne
//    @JsonManagedReference
//    @JoinColumn(name = "hair_color_id")
//    HairColor haircolor;


}


