package br.com.aulaapi.entities.peopleatri;

import br.com.aulaapi.entities.People;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "gender")
public class Gender {

    @Id
    @Column(name = "gender_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonBackReference
    private Integer id;

    @Column(name = "name", nullable = false)
    private String name;

    @JsonBackReference
    @OneToMany(mappedBy = "gender")
    private List<People> people;

}
