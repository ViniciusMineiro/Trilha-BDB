package br.com.aulaapi.entities.peopleatri;

import br.com.aulaapi.entities.People;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "birth_year")
public class BirthYear {

    @Id
    @Column(name = "birth_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonBackReference
    private Integer id;

    @Column(name = "year", nullable = false)
    @DateTimeFormat(pattern = "yyyy")
    private Date year;

    @Column(name = "age")
    private String age;

    @JsonBackReference
    @OneToOne(mappedBy = "birthyear")
    private People people;

}