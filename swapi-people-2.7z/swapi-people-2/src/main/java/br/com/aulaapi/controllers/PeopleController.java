package br.com.aulaapi.controllers;

import br.com.aulaapi.entities.People;
import br.com.aulaapi.services.PeopleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/people")
public class PeopleController {

    @Autowired
    PeopleService peopleService;

    @GetMapping
    @ResponseBody
    public List<People> searchUser(){

        return peopleService.searchUser();

    }

    @PostMapping()
    public People createPeople(@RequestBody People people) {

        return peopleService.createPeople(people);

    }

    @PutMapping()
    public People updatePeople(@RequestBody People people) {

        return peopleService.updatePeople(people);

    }

    @DeleteMapping()
    public People deletePeople(@RequestBody People people) {

        return peopleService.deletePeople(people);

    }

}
