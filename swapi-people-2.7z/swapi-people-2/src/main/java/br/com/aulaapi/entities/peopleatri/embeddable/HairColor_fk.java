package br.com.aulaapi.entities.peopleatri.embeddable;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class HairColor_fk implements Serializable {

    @Column(name = "color_id_fk")
    Integer color_id_fk;


    @Column(name = "people_id_fk")
    Integer people_id_fk;

}

