package br.com.aulaapi.entities.peopleatri;

import br.com.aulaapi.entities.People;
import br.com.aulaapi.entities.peopleatri.embeddable.HairColor_fk;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "hair_color")
public class HairColor {

    @EmbeddedId
    HairColor_fk id;
//
//    @Id
//    @Column(name = "hair_color_id", nullable = false)
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @JsonBackReference
//    private Integer hair_id;
//
//    @JsonBackReference
//    @OneToMany(mappedBy = "hair_color")
//    private Set<Color> color;
//
//    @JsonBackReference
//    @OneToMany(mappedBy = "hair_color")
//    private Set<People> people;


    @ManyToOne
    @MapsId("color_id_fk")
    @JsonBackReference
    @JoinColumn(name = "color_id")
    Color color;

    @ManyToOne
    @MapsId("people_id_fk")
    @JsonBackReference
    @JoinColumn(name = "people_id")
    People people;

//
//    int raiting;




}
