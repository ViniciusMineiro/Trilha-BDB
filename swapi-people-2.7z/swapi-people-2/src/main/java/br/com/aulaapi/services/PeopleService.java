package br.com.aulaapi.services;


import br.com.aulaapi.entities.People;
import br.com.aulaapi.repositories.PeopleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PeopleService {

    @Autowired
    PeopleRepository peopleRepository;

    public List<People> searchUser(){

        return peopleRepository.findAll();

    }

    public People createPeople(People people) {

        return peopleRepository.save(people);

    }

    public People updatePeople(People people) {

        return peopleRepository.save(people);

    }

    public People deletePeople(People people) {

        peopleRepository.delete(people);

        return people;

    }
}
