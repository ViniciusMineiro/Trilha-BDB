package br.com.aulaapi.entities;

import br.com.aulaapi.entities.peopleatri.BirthYear;
import br.com.aulaapi.entities.peopleatri.Gender;
import br.com.aulaapi.entities.peopleatri.HairColor;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "people")
public class People {

    @Id
    @Column(name = "people_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonBackReference
    private Integer id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "height")
    private Float height;

    @Column(name = "mass")
    private Float mass;

    @Column(name = "created")
    @DateTimeFormat
    private Date created;

    @Column(name = "edited")
    @DateTimeFormat
    private Date edited;

    @JsonManagedReference
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "gender_id")
    private Gender gender;

    @JsonBackReference
    @OneToOne
    @JoinColumn(name = "birth_year_id")
    private BirthYear birthyear;

//    @JsonManagedReference
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "hair_color_id")
//    private HairColor haircolor;

    @JsonManagedReference
    @OneToMany(mappedBy = "people")
    Set<HairColor> hair_color;



}
